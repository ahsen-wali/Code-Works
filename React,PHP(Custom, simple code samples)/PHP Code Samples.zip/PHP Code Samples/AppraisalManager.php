<?php
@define( 'ERROR', 0 );
@define( 'SUCCESS', 1 );
@define( 'SECTION_TITLE', 'Manage Appraisals' );
@define( 'ENTITY', 'Appraisals' );

class AppraisalManager {
	function __construct( $db ) {
		$this->tableName = 'appraisals';
		$this->idField = 'id';
		$this->db = $db;
		$this->error = '';
	}

	function getByID ( $id, $company_id, $period_id ) {
		// clean up incoming variables for security reasons
		$id = (int)$id;

		if ( $id ) {
			$sql = "SELECT a.*, b.first_name, b.last_name FROM $this->tableName a, employees b WHERE a.$this->idField = ? AND a.employee_id = b.id LIMIT 1";
			$stmt = $this->db->query( $sql, array( $id ) );

			if ( $stmt ) {
				// pull 1 record from the database
				if ( !( $row = $stmt->fetch() ) ) {
					return ERROR;
				} else {
					// clean up the output for the page calling this, no slashes will be included
					// Remove all slashes from outgoing text
					$row['first_name'] = $this->db->parseOutputString( $row['first_name'], false );
					$row['last_name'] = $this->db->parseOutputString( $row['last_name'], false );
					return $row;
				}
			} else {
				$this->error = 'Could not retrieve the specified record.';
				return ERROR;
			}
		} else {
			return false; // no valid number id was passed in
		}
	}

	function delete ( $id, $company_id, $period_id ) {
		// convert the $id to make sure a number is being passed in and not a string
		$id = (int)$id;
		$company_id = (int)$company_id;
		$period_id = (int)$period_id;

		// if the $id was passed in then go ahead and delete the item
		if ( $id && $company_id && $period_id ) {
			$sql = "DELETE FROM $this->tableName WHERE $this->idField = ? AND company_id = ? AND period_id = ? LIMIT 1;";

			if ( $this->db->exec( $sql, array( $id, $company_id, $period_id ) ) ) {
				// return true if the item was deleted successfully
				return SUCCESS;
			} else {
				// return false if there was an error and the item was not deleted
				$this->error = $this->db->error();
				return ERROR;
			}
		} else {
			return false;
		}
	}

	function getAppraisalsCount( $company_id, $period_id ) {
    if ( $company_id && $period_id ) {
  		$sql = "SELECT COUNT(*) AS cnt FROM $this->tableName WHERE company_id = ? AND period_id = ?;";
  		if ( $stmt = $this->db->query( $sql, array( $company_id, $period_id ) ) ) {
  			// pull 1 record from the database
  			if ( !( $row = $stmt->fetch() ) ) {
  				$this->error = 'An error occurred while getting the item count.';
  				return ERROR;
  			} else {
  				return $row['cnt'];
  			}
  		} else {
  			$this->error = 'Could not fetch a count from the database, please contact your administrator.';
  			return ERROR;
  		}
    } else {
      $this->error = 'Please provide a company ID and perid.';
      return ERROR;
    }
	}

	function getAppraisals( $company_id, $period_id, $offset, $rowsPerPage ) {
		$company_id = (int)$company_id;
		$period_id = (int)$period_id;

    if ( $company_id && $period_id ) {
  		$sql = "SELECT a.*, b.first_name, b.last_name, b.photo, c.status,
			( SELECT y.department FROM departments_and_employees x, departments y WHERE x.employee_id = a.employee_id AND x.department_id = y.id AND period_id = 2 ) AS department
  			FROM $this->tableName a, employees b, appraisal_statuses c
  			WHERE a.employee_id = b.id AND a.status_id = c.id AND a.company_id =? AND a.period_id = ?
  			ORDER BY b.last_name LIMIT $offset, $rowsPerPage;";
  		// pull records from the database
  		if ( $result = $this->db->query( $sql, array( $company_id, $period_id ) ) ) {
  			// return the resulting records
  			return $result;
  		} else {
  			// return false if there was an error and the item was not deleted
  			$this->error = $this->db->error();
  			return ERROR;
  		}
    } else {
      $this->error = 'Please provide a company ID and perid.';
      return ERROR;
    }
	}

	function error() {
		return $this->error;
	}

	function getRating_scales_TitleDropdown( $company_id, $period_id, $checked = false ) {
		$company_id = (int)$company_id;
		$period_id = (int)$period_id;

		$sql = "SELECT id, title FROM rating_scales WHERE company_id = ? AND period_id = ? ORDER BY title;";
		$stmt = $this->db->prepare( $sql );
		if ( $stmt->execute( array( $company_id, $period_id ) ) ) {
			return $this->db->buildDropdown( $stmt, $checked );
		} else {
			return ERROR;
		}
	}

	function getKey_development_factors_TitleDropdown( $company_id, $period_id, $checked = false ) {
		$sql = "SELECT id, title FROM key_development_factors WHERE company_id = ? AND period_id = ? ORDER BY title;";
		$stmt = $this->db->prepare( $sql );
		if ( $stmt->execute( array( $company_id, $period_id ) ) ) {
			return $this->db->buildDropdown( $stmt, $checked );
		} else {
			return ERROR;
		}
	}

	function getStatusDropdown( $checked = false ) {
		$sql = "SELECT id, status FROM project_goal_statuses ORDER BY sort;";
		$stmt = $this->db->prepare( $sql );
		if ( $stmt->execute( array() ) ) {
			return $this->db->buildDropdown( $stmt, $checked );
		} else {
			return ERROR;
		}
	}

	function addEmployee( $project_goal_id, $employee_id ) {
		$project_goal_id = (int)$project_goal_id;
		$employee_id = (int)$employee_id;
		if ( $project_goal_id && $employee_id ) {
			$sql = 'INSERT INTO project_goal_employees SET project_goal_id = ?, employee_id = ?';
			$this->db->exec( $sql, array( $project_goal_id, $employee_id ) );
		}
		return SUCCESS;
	}

	function clearEmployees( $project_goal_id ) {
		$project_goal_id = (int)$project_goal_id;
		if ( $project_goal_id ) {
			$sql = 'DELETE FROM project_goal_employees WHERE project_goal_id = ?';
			$this->db->exec( $sql, array( $project_goal_id ) );
			return SUCCESS;
		}
	}

	function addObjective( $project_goal_id, $title, $description, $status_id, $start_date, $due_date, $completed_date, $weight ) {
		$project_goal_id = (int)$project_goal_id;
		$title = $this->db->prepString( $title, 45 );
		$description = $this->db->prepString( $description, false );
		if ( !$start_date ) $start_date = null;
		if ( !$due_date ) $due_date = null;
		if ( !$completed_date ) $completed_date = null;

		if ( $project_goal_id ) {
			$sql = 'INSERT INTO project_goal_objectives SET date_created = NOW(), project_goal_id = ?, title = ?, description = ?, status_id = ?, start_date = ?, due_date = ?, completed_date = ?, weight = ?, last_updated = NOW()';
			$new_id = $this->db->exec( $sql, array( $project_goal_id, $title, $description, $status_id, $start_date, $due_date, $completed_date, $weight ), true );

			if ( $new_id ) {
				// return the id for the newly created entry
				return $new_id;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}

		}
		return SUCCESS;
	}

	function updateObjective( $appraisal_id, $project_goal_id, $objective_id, $due_date, $completed_date, $rating, $goal, $actual, $objective_type_id ) {
		// clean up incoming variables for security reasons
		$appraisal_id = (int)$appraisal_id;
		$project_goal_id = (int)$project_goal_id;
		$objective_id = (int)$objective_id;
		$rating = (int)$rating;
		$goal = (int)$goal;
		$actual = (int)$actual;

		if ( (int)$appraisal_id < 0 || $appraisal_id == '' ) $this->error = 'Please provide a valid appraisal ID.';
		if ( (int)$project_goal_id < 0 || $project_goal_id == '' ) $this->error = 'Please provide a valid project goal ID.';
		if ( (int)$objective_id < 0 || $objective_id == '' ) $this->error = 'Please provide a valid objective ID.';
		if ( $this->error != "" ) return ERROR;

		if ( $appraisal_id && $project_goal_id && $objective_id ) {

			// if the completed_date is passed then objective is done and we need to score
			if ( $completed_date ) {
				if ( $objective_type_id == 1 ) { // date based
					$score = strtotime( $due_date ) > strtotime( $completed_date ) ? $rating * 10 : $rating * 10 * .85;
				} else if ( $objective_type_id == 2 ) { // numeric based
					$sql = 'SELECT SUM( qty ) FROM appraisal_project_goal_objective_updates
									WHERE appraisal_id = ? AND appraisal_project_goal_id = ? AND appraisal_project_goal_objective_id = ?';
					$sums = $this->db->query( $sql, array( $appraisal_id, $project_goal_id, $objective_id ) );
					if ( $this->db->num_rows() > 0 ) {
						$sum = $this->db->fetch( $sums );
						$score = $goal >= $actual ? 100 : (int)( $actual / $goal * 100 );
					}
					$score = strtotime( $due_date ) > strtotime( $completed_date ) ? $score : (int)( $score * .85 );
				} else if ( $objective_type_id == 3 ) { // score based
					$score = $goal <= $actual ? 100 : (int)( $actual / $goal * 100 );
					$score = strtotime( $due_date ) > strtotime( $completed_date ) ? $score : (int)( $score * .85 );
				}
			} else {
				$score = '';
			}

			$sql = "UPDATE appraisal_project_goal_objectives SET completed_date = ?, rating = ?, actual = ?, score = ? WHERE $this->idField = ? AND appraisal_id = ? AND appraisal_project_goal_id = ? LIMIT 1;";
			$params = array( $completed_date, $rating, $actual, $score, $objective_id, $appraisal_id, $project_goal_id );

			if ( $this->db->exec( $sql, $params ) ) {
				// return true if the item was updated successfully
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}
		} else {
			return false;
		}
	}

	function updateIGObjective( $appraisal_id, $project_goal_id, $objective_id, $due_date, $completed_date, $rating, $goal, $actual, $objective_type_id ) {
		// clean up incoming variables for security reasons
		$appraisal_id = (int)$appraisal_id;
		$project_goal_id = (int)$project_goal_id;
		$objective_id = (int)$objective_id;
		$rating = (int)$rating;
		$goal = (int)$goal;
		$actual = (int)$actual;

		if ( (int)$appraisal_id < 0 || $appraisal_id == '' ) $this->error = 'Please provide a valid appraisal ID.';
		if ( (int)$project_goal_id < 0 || $project_goal_id == '' ) $this->error = 'Please provide a valid project goal ID.';
		if ( (int)$objective_id < 0 || $objective_id == '' ) $this->error = 'Please provide a valid objective ID.';
		if ( $this->error != "" ) return ERROR;

		if ( $appraisal_id && $project_goal_id && $objective_id ) {
			$sql = "UPDATE appraisal_project_goal_objectives SET completed_date = ?, rating = ?, actual = ?, score = ? WHERE $this->idField = ? AND appraisal_id = ? AND appraisal_project_goal_id = ? LIMIT 1;";
			$params = array( $completed_date, $rating, $actual, $score, $objective_id, $appraisal_id, $project_goal_id );

			if ( $this->db->exec( $sql, $params ) ) {
				// return true if the item was updated successfully
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}
		} else {
			return false;
		}
	}

	function removeObjective( $project_goal_id, $objective_id ) {
		$project_goal_id = (int)$project_goal_id;
		$objective_id = (int)$objective_id;

		if ( $project_goal_id && $objective_id ) {
			$sql = 'DELETE FROM project_goal_objectives WHERE project_goal_id = ? AND id = ?';
			if ( $this->db->exec( $sql, array( $project_goal_id, $objective_id ) ) ) {
				// return the id for the newly created entry
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}

		}
		return SUCCESS;
	}

	function setCompetencyScore( $appraisal_id, $competency_id, $score ) {
		$appraisal_id = (int)$appraisal_id;
		$competency_id = (int)$competency_id;
		$score = (int)$score;

		if ( $appraisal_id && $competency_id ) {
			$sql = 'UPDATE appraisal_competencies SET score = ? WHERE id = ? AND appraisal_id = ?';
			if ( $this->db->exec( $sql, array( $score, $competency_id, $appraisal_id ) ) ) {
				// return the id for the newly created entry
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}

		}
		return SUCCESS;
	}

	function setProjectGoalScore( $appraisal_id, $project_goal_id, $score ) {
		$appraisal_id = (int)$appraisal_id;
		$project_goal_id = (int)$project_goal_id;
		$score = (int)$score;

		if ( $appraisal_id && $project_goal_id ) {
			$sql = 'UPDATE appraisal_project_goals SET score = ? WHERE id = ? AND appraisal_id = ?';
			if ( $this->db->exec( $sql, array( $score, $project_goal_id, $appraisal_id ) ) ) {
				// return the id for the newly created entry
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}

		}
		return SUCCESS;
	}

	function setIndividualGoalScore( $appraisal_id, $individual_goal_id, $score ) {
		$appraisal_id = (int)$appraisal_id;
		$individual_goal_id = (int)$individual_goal_id;
		$score = (int)$score;

		if ( $appraisal_id && $individual_goal_id ) {
			$sql = 'UPDATE appraisal_individual_goals SET score = ? WHERE id = ? AND appraisal_id = ?';
			if ( $this->db->exec( $sql, array( $score, $individual_goal_id, $appraisal_id ) ) ) {
				// return the id for the newly created entry
				return SUCCESS;
			} else {
				$this->error = $this->db->error();
				return ERROR;
			}

		}
		return SUCCESS;
	}

	function updateStatus( $project_goal_id, $status_id ) {
		$project_goal_id = (int)$project_goal_id;
		$status_id = (int)$status_id;
		if ( $project_goal_id && $status_id ) {
			if ( $status_id == 2 ) { // ready for manager review, notify all persons who this has been cascaded to
				$template = $this->getEmailTemplate( 5 ); // get the manager review template

				$sql = 'SELECT a.employee_id, b.first_name, b.email FROM project_goal_employees a, employees b
								WHERE a.project_goal_id = ? AND a.employee_id = b.id ORDER BY b.last_name';
				$emps = $this->db->query( $sql, array( $project_goal_id ) );
				if ( $this->db->num_rows() > 0 ) {
					while( $emp = $this->db->fetch( $emps ) ) {
						if ( $emp['email'] ) {
							$cur_message = $body;
							$cur_message = str_replace( '{FNAME}', $emp['first_name'], $cur_message );
							$cur_message = str_replace( '{LNAME}', $emp['first_name'], $cur_message );
							$cur_message = str_replace( '{BODY}', $cur_message, $template );
							$cur_message = str_replace( '{HOST}', $_SERVER['HTTP_HOST'], $template );
							$cur_message = str_replace( '{PID}', $project_goal_id, $template );
							$headers .= "MIME-Version: 1.0\r\n";
							$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

							//mail( $emp['email'], $subject, $cur_message, $headers );
						}

					}
				}
			} else if ( $status_id == 4 ) { // Approved
				// do nothing
			}
			return SUCCESS;
		} else {
			$this->error = 'Please provide a valid project goal ID and status.';
			return ERROR;
		}
	}

	function getObjectiveMonthlyValue( $objective_id, $month ) {
		$objective_id = (int)$objective_id;
		$month = (int)$month;

		if ( $objective_id && $month ) {
			$sql = 'SELECT month_val FROM project_goal_objective_month_values
							WHERE project_goal_objective_id = ? AND month_no = ?';
			$mos = $this->db->query( $sql, array( $objective_id, $month ) );
			if ( $this->db->num_rows() > 0 ) {
				if ( $mo = $this->db->fetch( $mos ) ) {
					return $mo['month_val'];
				}
			} else {
				$this->error = 'No valid updates found.';
			}
		} else {
			$this->error = 'Please pass in all required parameters.';
		}
	}

	function getNumericObjectiveActual( $appraisal_id, $appraisal_objective_id ) {
		$appraisal_id = (int)$appraisal_id;
		$appraisal_objective_id = (int)$appraisal_objective_id;
		$actual = 0;

		if ( $appraisal_objective_id ) {
			$sql = 'SELECT actual FROM appraisal_project_goal_objectives WHERE id = ? AND appraisal_id = ?';
			$objs = $this->db->query( $sql, array( $appraisal_objective_id, $appraisal_id ) );
			if ( $this->db->num_rows() > 0 ) {
				$obj = $this->db->fetch( $objs );
				$actual = $obj['actual'];
			}
		} else {
			$this->error = 'Please provide all required parameters.';
			$actual = 0;
		}
		return $actual;
	}

	function getEmailTemplate( $id ) {
		$id = (int)$id;
		if ( $id ) {
			$sql = 'SELECT template FROM email_templates WHERE id = ?';
			$temps = $this->db->query( $sql, array( $id ) );
			if ( $this->db->num_rows() > 0 ) {
				$temp = $this->db->fetch( $temps );
				return $temp['template'];
			} else {
				$this->error = 'Could not find the specified template';
				return ERROR;
			}
		} else {
			$this->error = 'Please pass in a valid ID.';
			return ERROR;
		}
	}

}
?>