<?php
session_start();
require( '../includes/pdo.php' );
require( '../includes/check_login.php' );
require( '../includes/AppraisalManager.php' );
$Appraisal = new AppraisalManager( $conn );
$msg = '';

// check variables passed in through querystring
$id = isset( $_GET['id'] ) ? (int)$_GET['id'] : 0;
$update = isset( $_POST['update'] ) ? (int)$_POST['update'] : 0;
$jump_anchor_id = '';
$month_lbls  = array( '', 'July', 'August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June' );

// if an id is passed in then let's fetch it from the database
if ( $id ) {
	$token = $_SESSION['upd_token'];
	unset( $_SESSION['upd_token'] );

	if ( !( $row = $Appraisal->getByID( $id, $_SESSION['admin_company_id'], $_SESSION['admin_period_id'] ) ) ) {
		$msg = "Sorry, a record with the specified ID could not be found!";
	}
	if ( isset( $_POST['update_objective'] ) ) {
		$objmsg = array();
		$objerr = array();
		if ( $Appraisal->updateObjective( $id, $_POST['project_goal_id'], $_POST['objective_id'], $_POST['due_date'], $_POST['completed_date'], isset( $_POST['rating'] ) ? $_POST['rating'] : '', $_POST['goal'], isset( $_POST['actual'] ) ? $_POST['actual'] : '', $_POST['objective_type_id'] ) ) {
			$objmsg[(int)$_POST['objective_id']] = 'Your objective was updated successfully.';
		} else {
			$objerr[(int)$_POST['objective_id']] = 'Your objective could not be updated. Err: ' . $Appraisal->error();
		}
		$jump_anchor_id = 'obj_' . $_POST['objective_id'];
	}

	if ( isset( $_POST['update_ig_objective'] ) ) {
		$objigmsg = array();
		$objigerr = array();
		if ( $Appraisal->updateIGObjective( $id, $_POST['individual_goal_id'], $_POST['objective_id'], $_POST['due_date'], $_POST['completed_date'], isset( $_POST['rating'] ) ? $_POST['rating'] : '', $_POST['goal'], isset( $_POST['actual'] ) ? $_POST['actual'] : '', $_POST['objective_type_id'] ) ) {
			$objigmsg[(int)$_POST['objective_id']] = 'Your objective was updated successfully.';
		} else {
			$objigerr[(int)$_POST['objective_id']] = 'Your objective could not be updated. Err: ' . $Appraisal->error();
		}
		$jump_anchor_id = 'ig_obj_' . $_POST['objective_id'];
	}

}
// create a token for secure deletion (from this page only and not remote)
$_SESSION['upd_token'] = md5( uniqid() );
session_write_close();
$obj_count = array();
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="../images/cropped-favicon-150x150.png" sizes="32x32">
  <link rel="icon" href="../images/cropped-favicon-300x300.png" sizes="192x192">
  <link rel="apple-touch-icon-precomposed" href="../images/cropped-favicon-300x300.png">
  <title>Edit a <?php echo ENTITY; ?></title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-Bx4pytHkyTDy3aJKjGkGoHPt3tvv6zlwwjc3iqN7ktaiEMLDPqLSZYts2OjKcBx1" crossorigin="anonymous">
	<link href="/manager/css/jquery.fancybox.min.css" rel="stylesheet">
	<link href="/manager/css/imagine.css" rel="stylesheet">
	<link href="/manager/css/appraisal_builder.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg="	crossorigin="anonymous"></script>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<style>
	.comp_ws { float: right; width: 230px; font-weight: bold; }
	.app_weight { float: left; width: 115px; background-color: #e1e1e1; color: #ed5e36; text-align: center; padding: 8px 8px; }
	.app_score { float: right; width: 115px;  background-color: #ed5e36; color: #fff; text-align: center; padding: 8px 8px;}
	.comp_heading {padding-bottom: 15px;}
	.comp_heading h3 {display: inline-block;padding-top: 6px;}
	.new_update_form { padding-top: 20px; }
	</style>
	<script>
	$(document).ready(function() {
		$('form:first *:input[type!=hidden]:first').focus();
/*
		tinymce.init({
				selector: "textarea",
				plugins:["link image hr fullscreen media table textcolor code filemanager"],
				toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link code responsivefilemanager table | forecolor backcolor",
				external_filemanager_path: "/manager/includes/tinymce/plugins/filemanager/",
				filemanager_title: "File manager", relative_urls: false, image_advtab: true,
				external_plugins: { "filemanager" : "/manager/includes/tinymce/plugins/filemanager/plugin.min.js"}
			});

			*/
	});
	</script>
	<!--script type="text/javascript">tinymce.init({
			selector: "textarea#obj_description",
			plugins:["link image hr fullscreen media table textcolor code filemanager"],
			toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link code responsivefilemanager table | forecolor backcolor",
			external_filemanager_path: "/manager/includes/tinymce/plugins/filemanager/",
			filemanager_title: "File manager", relative_urls: false, image_advtab: true,
			external_plugins: { "filemanager" : "/manager/includes/tinymce/plugins/filemanager/plugin.min.js"}
		});
</script-->
	<style>
		body {font-family: 'ITCAvantGardeGothicLTMedium';}
	.weight_sum, .final_score { color: #f26522; font-family: ITCAvantGardeStd-Bold;font-size: 30px;padding-top: 2px;}
	#project_weight_sum.weight_sum {color: #3295CD;}
	#individual_weight_sum.weight_sum {color: #00863f;}
	.final_score {padding-top: 4px;position: absolute;right: 15px;}
	.weight_sum {margin-right: 15px;padding-top: 4px;position: absolute;}
	.final_text, .final_score {color: #505050;}
	.final_text {margin-left: 65px;padding-right: 67px;}
    .total-weight {float: right;border: 2px solid #f26522;border-radius: 20px;font-family: ITCAvantGardeGothicLTMedium;padding: 10px;font-size: 12px;position: relative;}
    .blue .total-weight {border: 2px solid #3295CD;}
    .green .total-weight {border: 2px solid #00863f;}
	.no_updates { padding: 5px 10px; margin: 2px 0px; }
	.objective_section { /*background-color: #F3F3F3;*/ padding: 20px; border-radius: 10px; margin-left: 15px;}
	.objective_section .note { background-color: #F3F3F3; padding-bottom: 1rem;border-radius: 10px 10px 0 0;margin-bottom: 0;margin-top: 30px;}
	.note-content { background-color: #F3F3F3!important; border-radius: 10px; padding: 20px 20px!important; }
	.objective_title { font-size: 24px; }
	.update_section { background-color: #FFF; border-radius: 10px; padding: 20px; }
	.mgr_approval { position: absolute;right: 40px;background-color: #CCC; padding: 15px 20px 5px 15px; border-radius: 10px; text-transform: uppercase; font-weight: bold;}
	.mgr_approval label { float: left; background-color: transparent; color: #00863F; min-width: 120px; padding: 0.1rem .8rem;}
	.mgr_approval .chkMgrApproved, .mgr_approval .chkMgr110, .mgr_approval .chkIGMgrApproved, .mgr_approval .chkIGMgr110 { float: right; margin-top: 8px;}
	.mgr_approval .chkMgrApproved {margin-top: 12px;}
	.mgr_approval .chkIGMgrApproved {margin-top: 13px;}
	.mgr_approval .chkMgr110 {margin-top: 5px;}
	#competencies {margin-top: 45px;}
	.appraisal_project_goal h3, .appraisal_individual_goal h3 {margin-bottom: 30px;}
	.appraisal_project_goal h4, .appraisal_individual_goal h4 {margin: 15px;}
	.mgr_approval input[type="checkbox"]:before {
	  position: relative;
	  display: block;
	  width: 15px;
	  height: 15px;
	  border: 2px solid #565656;
	  content: "";
	  background: #ccc;
	  border-radius: 4px;
	}
	.mgr_approval input[type="checkbox"]:after {
	  	position: relative;
	    display: block;
	    content: "";
	    border-radius: 4px;
	    left: -2px;
	    top: -22px;
	    width: 26px;
	    height: 26px;
	}
	.mgr_approval input[type="checkbox"]:checked:after {
  		background-image: url(../images/green-check.png);
    	background-size: contain;
	}
	.note-description.px-2 p { width: 80%; }
	.total_plus {
		position: absolute;
	    background-color: #ED5E36;
	    border-radius: 50%;
	    display: inline-block;
	    color: #fff;
	    font-size: 16px;
	    text-align: center;
	    padding: 0px 9px 4px;
    	top: 8px;
    	cursor: pointer;
    	right: -15px;
    	font-family: 'ITCAvantGardeGothicLTMedium';
	}
	.blue .total_plus {
	    background-color: #3295CD;
	}
	.green .total_plus {
	    background-color: #00863f;
	}
	.comp_total_toggle, .proj_total_toggle, .ind_total_toggle {
		display: none;
		background-color: #ebebeb;
		padding: 15px;
		border-radius: 10px;
		margin-top: 45px;
		font-size: 13px;
	}
	.btn-sm {font-size: 1rem;}
	input.form-control {color: green;}
	input#rating, input#actual, input#goal, input#goal_score, .form-group input[type="number"].actual_score {
		font-size: 24px;
		font-weight: bold;
		color: #a8a8a8;
		padding: .7rem 1.5rem;
	}
	.project_goal_objective_form, .individual_goal_objective_form {
		background-color: #F3F3F3; border-radius: 0 0 15px 15px; padding: 20px; margin-bottom: 30px;
	}
	.note-content.note-content-update {
    	background-color: transparent!important;
	}
	.update_section h4 {
		font-size: 1.4em;
	}
	</style>
</head>

<body>
	<?php include( '../includes/header.php' ); ?>

	  <div class="container-fluid" id="main">
	    <div class="row row-offcanvas row-offcanvas-left">

	      <?php include( '../includes/nav.php' ); ?>

	        <div class="col main pt-5 mt-3 col-md-6 col-lg-8">
	          <div class="row mgr_heading">
	            <div class="col-lg-10">
								<?php
								$sql = 'SELECT * FROM periods WHERE id = ?';
								$pds = $conn->query( $sql, array( $_SESSION['admin_period_id'] ) );
								if ( $conn->num_rows() > 0 ) {
									while ( $pd = $conn->fetch( $pds ) ) {
										echo '<h3>Appraisal for ' . stripslashes( $row['first_name'] ) . ' ' . stripslashes( $row['last_name'] ) . ' <small>' . stripslashes( $pd['title'] ) . '</small></h3>';
										if ( $pd['appraisal_header_image'] ) echo '<img src="/assets/' . $_SESSION['admin_unique_id'] . '/periods/' . $pd['appraisal_header_image'] . '" class="float-left img-responsive mb-30" style="max-width: 100%;">';
										echo '<h4>' . stripcslashes( $pd['appraisal_header_title'] ) . '</h4>';
										if ( $pd['appraisal_header_logo'] ) echo '<img src="/assets/' . $_SESSION['admin_unique_id'] . '/periods/' . $pd['appraisal_header_logo'] . '" class="float-left" width="150">';
										echo '<p>' . stripcslashes( $pd['appraisal_header_content'] ) . '</p>';
										if ( $pd['appraisal_header_link'] && $pd['appraisal_header_link_caption'] ) echo '<a href="' . $pd['appraisal_header_link'] . '" target="main">' . $pd['appraisal_header_link_caption'] . '</a>';

									}
								}
								?>
	            </div>
	          </div>

	          <div class="row my-4 mgr_body">

	            <div class="col-xl-10 col-lg-8 col-md-8">

								<?php
								if ( $row ) {
									$sql = 'SELECT competency_weight, project_goal_weight, individual_goal_weight FROM periods WHERE id = ?';
									$periods = $conn->query( $sql, array( $_SESSION['admin_period_id'] ) );
									if ( $conn->num_rows() > 0 ) {
										$period = $conn->fetch( $periods );
										$competencies_weight = $period['competency_weight'];
										$project_goals_weight = $period['project_goal_weight'];
										$individual_goals_weight = $period['individual_goal_weight'];
									} else {
										$competencies_weight = -1;
										$project_goals_weight = -1;
										$individual_goals_weight = -1;
									}

								?>
								<!-- ################################### COMPETENCIES SECTION ################################ -->
								<a name="comps"></a>
								<div class="competencies-top">
									<h4 class="orange builder_title">Competencies <a href="" onClick="$('#competencies').toggle('slow');"></a> <div class="total-weight">TOTAL WEIGHT &nbsp;
										<span id="weight_sum" class="weight_sum"><?php echo $competencies_weight; ?>%</span> <span class="final_text">FINAL SCORE</span> &nbsp;<span id="final_score" class="final_score"> 17%</span><span class="total_plus">+</span></div></h4>
								</div>
								<div class="comp_total_toggle">Please see the chart below for an explanation of how your score was calculated:
									<br>
									<table border="1" cellpadding="5">
										<tr><th>Score</th><th>Percent</th></tr>
										<tr><td>4.5 to 5.0</td><td>20%</td></tr>
										<tr><td>4.0 to 4.4</td><td>18%</td></tr>
										<tr><td>3.5 to 3.9</td><td>16%</td></tr>
										<tr><td>3.0 to 3.4</td><td>14%</td></tr>
										<tr><td>2.5 to 2.9</td><td>10%</td></tr>
										<tr><td>Under 2.5</td><td>5%</td></tr>
									</table>
								</div>
								<div id="competencies">

											<?php
											$sql = 'SELECT a.*, d.title, b.desc_mgr, b.desc_emp
															FROM appraisal_competencies a, period_competencies b, appraisals c, competencies d
															WHERE a.appraisal_id = ? AND a.competency_id = b.competency_id AND a.appraisal_id = c.id AND a.competency_id = d.id AND c.company_id = ? AND b.period_id = ?';
											$comps = $conn->query( $sql, array( $row['id'], $_SESSION['admin_company_id'], $_SESSION['admin_period_id'] ) );

											if ( $conn->num_rows() > 0 ) {
												while( $comp = $conn->fetch( $comps ) ) {
													//$description = strip_tags( $comp['desc_mgr'] );
													$description = stripslashes( $comp['desc_mgr'] );
													echo '
												<a name="co_' . $comp['id'] . '"></a>
												<div class="appraisal_competency competency_' . $comp['id'] . '">
													<div class="comp_heading">
														<h3>' . $conn->parseOutputString( $comp['title'] ) . '</h3>
														<div class="comp_ws">
															<div class="app_weight">Weight: ' . $comp['weight'] . '%</div>
															<div class="app_score">Score: ' . $comp['score'] . '</div>
														</div>
													</div>
													<div class="clearfix"></div>
													<p>
														<!--div class="float-right mx-2 input-competency-weight text-center">Weight
															<input type="text" name="" class="form-control text-center input-sm competency-weight" value="' . $comp['weight'] . '" data-appraisal-id="' . $id . '" data-competency-id="' . $comp['competency_id'] . '" data-employee-id="' . $comp['employee_id'] . '">
															&nbsp;<br>' . $comp['score'] . '
														</div-->
														' . $description . '
													</p>
													';
											?>
													<div class="row objective_section">
														<h4 class="mx-3">Notes (<span id="sec_note_count_<?php echo $comp['id']; ?>"><?php echo (int)$comp['note_count']; ?></span>) <a class="" href="#comp_notes_<?php echo $comp['id']; ?>" data-toggle="collapse" aria-expanded="false" aria-controls="comp_notes_<?php echo $comp['id']; ?>"><i class="fal fa-chevron-circle-down "></i></a></h4>
														<div class="form-group col-md-12 collapse" id="comp_notes_<?php echo $comp['id']; ?>">
															<a name="notes" id="notes_<?php echo $comp['id']; ?>"></a>

															<?php
															$obj_count = 0;
															if ( $comp['id'] ) {
																$obj_count = 0;
																$sql = 'SELECT * FROM appraisal_competency_notes WHERE appraisal_competency_id = ? ORDER BY date_created';
																$notes = $conn->query( $sql, array(  $comp['id'] ) );
																if ( $conn->num_rows() > 0 ) {
																	// display the notes
																	while( $note = $conn->fetch( $notes ) ) {
																		echo '<div id="comp_note_' . $note['id'] . '" class="note form-group">' . "\n";
																		echo '	<div class="note-content">' . "\n";
																		echo '		<div class="note-description px-2">' . "\n";
																		echo '			' . stripslashes( $note['note'] ) . "\n";
																		echo '			<div class="clearfix note_date"> Added on ' . date( 'm/d/Y h:i a', strtotime( $note['date_created'] ) ) . '</div>';
																		echo "		</div>\n";
																		echo '		<div class="note-actions note-actions-center">' . "\n";
																		echo '			<a href="../appraisal_competency_notes/edit.php?id=' . $note['id'] . '&aid=' . $id . '&cid=' . $comp['id'] . '" data-fancybox data-type="iframe"><button type="button" class="btn btn-edit mr-2">Edit <i class="far fa-edit"></i></button></a>' . "\n";
																		echo '			<button type="button" name="delete_note_' . $note['id'] . '" class="btn btn-default removeCompetencyNote" data-id="' . $note['id'] . '">Delete <i class="far fa-trash-alt"></i></button>' . "\n";
																		echo "		</div>\n";
																		echo "	</div>\n";
																		echo "</div>\n\n";
																		echo '<input type="hidden" id="note_' . $note['id'] . '_competency_id" name="note_' . $note['id'] . '_competency_id" value="' . $comp['id'] . '">' . "\n";

																		$obj_count++;
																	}
																} else {
																	echo '<div class="alert alert-primary alert_note alert_no_notes_' . $comp['id'] . '">No notes have been created.</div>';
																}
																echo '<input type="hidden" id="note_count_' . $comp['id'] . '" name="note_count_' . $comp['id'] . '" value="' . $obj_count . '">' . "\n";
															}
															?>
															<button id="new_note_<?php echo $comp['id']; ?>" class="btn btn-primary float-right new_competency_note" data-id="<?php echo $comp['id']; ?>"><i class="far fa-plus"></i> Add New Note</button>
														</div>
													</div>

											<?php
													echo '
												</div>
													';
												}
											} else {
												echo '<div class="alert alert-warning">No competencies found.</div>';
											}
											?>

								</div>
								<!-- ################################### //COMPETENCIES SECTION ################################ -->


								<!-- ################################### PROJECT GOAL SECTION ################################ -->
								<a name="pro_goals">&nbsp;</a>
								<h4 class="blue builder_title">Project Goals <div class="total-weight">TOTAL WEIGHT &nbsp;
									<span id="project_weight_sum" class="weight_sum"><?php echo $project_goals_weight; ?>%</span> <span class="final_text">FINAL SCORE</span> &nbsp;<span id="project_final_score" class="final_score"> 17%</span><span class="total_plus">+</span></div></h4>
								<div class="proj_total_toggle">Please see the chart below for an explanation of how your score was calculated:
									<br>
									<table border="1" cellpadding="5">
										<tr><th>Score</th><th>Percent</th></tr>
										<tr><td>4.5 to 5.0</td><td>20%</td></tr>
										<tr><td>4.0 to 4.4</td><td>18%</td></tr>
										<tr><td>3.5 to 3.9</td><td>16%</td></tr>
										<tr><td>3.0 to 3.4</td><td>14%</td></tr>
										<tr><td>2.5 to 2.9</td><td>10%</td></tr>
										<tr><td>Under 2.5</td><td>5%</td></tr>
									</table>
								</div>
								<div id="project_goals" class="appraisal_section">
											<?php
											$sql = 'SELECT a.*, b.title, b.description FROM appraisal_project_goals a, project_goals b WHERE a.appraisal_id = ? AND a.project_goal_id = b.id';
											$goals = $conn->query( $sql, array( $row['id'] ) );
											if ( $conn->num_rows() > 0 ) {
												while( $goal = $conn->fetch( $goals ) ) {
													$description = stripslashes( $goal['description'] );
													echo '
												<a name="pg_' . $goal['id'] . '"></a>
												<div class="appraisal_project_goal project_goal_' . $goal['id'] . '">
													<h3>' . $conn->parseOutputString( $goal['title'] ) . '</h3>
													<p>' . $description . '</p>
													';
											?>

											<div class="row">
												<h4 class="float-left">Objectives</h4>
												<div class="clearfix"></div>
												<div class="form-group col-md-12 objective_section" id="project_goal_objectives_<?php echo $goal['id']; ?>">

													<?php
													$obj_count = 0;
													if ( $goal['id'] ) {
														$obj_count = 0;
														$sql = 'SELECT a.*, b.title, b.description, b.objective_type_id, c.status, d.objective_type
																		FROM appraisal_project_goal_objectives a, project_goal_objectives b, project_goal_objective_statuses c, objective_types d
																		WHERE a.appraisal_id = ? AND a.appraisal_project_goal_id = ? AND a.objective_id = b.id AND a.status_id = c.id AND b.objective_type_id = d.id
																		ORDER BY date_created DESC';
														$objs = $conn->query( $sql, array(  $id, $goal['id'] ) );
														if ( $conn->num_rows() > 0 ) {
															// display the notes
															while( $obj = $conn->fetch( $objs ) ) {
																$start_date = !empty( $obj['start_date'] ) ? date( 'm/d/Y', strtotime( $obj['start_date'] ) ) : '';
																$due_date = !empty( $obj['due_date'] ) ? date( 'm/d/Y', strtotime( $obj['due_date'] ) ) : '';
																$completed_date = !empty( $obj['completed_date'] ) ? date( 'm/d/Y', strtotime( $obj['completed_date'] ) ) : '';
																echo '<a id="obj_' . $obj['id'] . '"></a>';
																echo '<div id="project_goal_objective_' . $obj['id'] . '" class="note form-group">' . "\n";
																echo '	<div class="note-content">' . "\n";
																echo '		<div class="note-description px-2">' . "\n";

																if ( isset( $objmsg[(int)$obj['id']] ) ) {
																	echo '<div class="alert alert-success alert-obj-upd" style="clear: both;">' . $objmsg[(int)$obj['id']] . '</div>';
																}
																if ( isset( $err[(int)$obj['id']] ) ) {
																	echo '<div class="alert alert-danger alert-obj-upd" style="clear: both;">' . $objerr[(int)$obj['id']] . '</div>';
																}

																echo '			<div id="mgr_approval_' . $obj['id'] . '" class="mgr_approval">
																			';
																if ( $obj['mgr_approved'] && $completed_date ) {
																	echo '<div class="obj_score"><label>Score</label>' . $obj['score'] . '%</div>';
																}

																echo '
																							<div><label for="chkMgrApproved_' . $obj['id'] . '">Manager<br> Approved </label><input type="checkbox" id="chkMgrApproved_' . $obj['id'] . '" class="chkMgrApproved" data-objective-title="' . htmlspecialchars( $obj['title'] ) . '"  data-objective-id="' . $obj['id'] . '" ' . ( (int)$obj['mgr_approved'] ? 'CHECKED DISABLED' : '' ) . '></div>
																							<div><label for="chkMgr110_' . $obj['id'] . '">110% </label><input type="checkbox" id="chkMgr110_' . $obj['id'] . '" class="chkMgr110"  data-objective-id="' . $obj['id'] . '" ' . ( (int)$obj['mgr_110'] ? 'CHECKED DISABLED' : '' ) . '></div>
																						</div>
																';

																echo '			<strong class="objective_title">' . stripslashes( $obj['title'] ) . "</strong><br>\n";
																echo '			' . stripslashes( $obj['description'] ) . "<br>\n
																						<div class=\"row my-3\">
																							<div class=\"obj_label\"><strong>Status:</strong> " . $obj['status'] . "</div>
																							<div class=\"obj_label\"><strong>Start:</strong> " . $start_date . "</div>
																							<div class=\"obj_label\"><strong>Due:</strong> " . $due_date . "</div>
																							<div class=\"obj_label\"><strong>Completed:</strong> " . $completed_date . "</div>
																							<div class=\"obj_label\"><strong>Weight:</strong> " . $obj['weight'] . "</div>
																							<div class=\"obj_label\"><strong>Type:</strong> " . $obj['objective_type'] . "</div>
																						</div>
																							";

																///////////////////////
																// UPDATES
																///////////////////////


																echo "
																						</div>
																";


																echo '<div class="update_section">
																				<h4>Updates</h4>
																				<div id="updates_' . $obj['id'] . '" class="updates">
																				';
																$sql = 'SELECT a.*, b.first_name, b.last_name, c.first_name AS employee_fname, c.last_name AS employee_lname
																				FROM appraisal_project_goal_objective_updates a, Admins b, employees c
																				WHERE a.appraisal_project_goal_objective_id = ? AND a.admin_id = b.id AND a.employee_id = c.id
																				ORDER BY a.month_no';
																$upds = $conn->query( $sql, array( $obj['id'] ) );
																$upd_count = 0;
																if ( $conn->num_rows() > 0 ) {
																	while ( $upd = $conn->fetch( $upds ) ) {
																		echo '	<div id="upd_' . $upd['id'] . '" class="note-content note-content-update">' . "\n";
																		echo '		<div class="note-description px-2">' . "\n";
																		echo '
																					<div class="row">
																					';

																		if ( (int)$obj['objective_type_id'] == 1 ) { // Date based
																			if ( (int)$upd['status'] == 0 )
																				echo '
																					<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																					';
																		} else if ( (int)$obj['objective_type_id'] == 2 ) { // Number based
																			$month_lbl = $month_lbls[(int)$upd['month_no']];
																			echo '
																				<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																				<div class="obj_label_mo"><strong>Month:</strong> ' . $month_lbl . '</div>
																				<div class="obj_label_qty"><strong>Qty:</strong> ' . $upd['qty'] . '</div>
																				';
																		} else {
																			echo '
																				<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																				<div class="obj_label_date"><strong>Date:</strong> ' . date( 'm/d/Y', strtotime( $upd['date_created'] ) ) . '</div>
																				';
																		}

																		if ( (int)$upd['admin_id'] > 1 )
																			echo '<div class="obj_label"><strong>Entered by:</strong> ' . $upd['first_name'] . ' ' . $upd['last_name'] . '</div>';
																		else
																			echo '<div class="obj_label"><strong>Entered by:</strong> ' . $upd['employee_fname'] . ' ' . $upd['employee_lname'] . '</div>';

																			echo '
																			<div class="upd_buttons">
																			';

																			if ( $upd['attachment'] )
																				echo '<a href="/assets/FuTaiElaIQ/appraisal_project_goal_updates/' . $upd['attachment'] . '" title="Download Attachment" download><img src="/manager/images/ico_paper_clip.png" height="26" width="17"></a>';
																			else
																				echo '<a href="#"><img src="/manager/images/blank.png" height="26" width="17"></a>';

																			echo '
																				<a href="edit_project_goal_objective.php?aid=' . $id . '&gid=' . $goal['id'] . '&oid=' . $obj['id'] . '&id=' . $upd['id'] . '" data-fancybox data-type="iframe" class="btn btn-default btn-small btn-edit">Edit<i class="fal fa-edit"></i></a>
																				<button class="btn btn-small btn-remove removeIGUpdate" data-id="' . $upd['id'] . '" data-project-goal-id="' . $goal['id'] . '" data-objective-id="' . $obj['id'] . '">Del<i class="fas fa-trash"></i></button>
																			</div>
																			';


																		echo '<!--/div-->
																					</div><!--// row -->
																		';
																		$upd_count++;
																		echo '	</div>' . "\n";
																		echo '</div>' . "\n";
																	}
																} else {
																	echo "\n<div id=\"no_updates_" . $obj['id'] . "\" class=\"no_updates\">No updates have been posted</div>\n";
																}

																echo '
																				</div> <!-- // updates -->
																				<button id="new_proj_obj_update_' . $obj['id'] . '" class="btn btn-primary new_objective_update btn-sm" data-id="' . $obj['id'] . '" data-type-id="' . $obj['objective_type_id'] . '" data-objective-id="' . $obj['objective_id'] . '" data-project-goal-id="' . $goal['id'] . '" data-project-type-id="' . $obj['objective_type_id'] .
																				'" data-project-goal-id="' . $goal['id'] . '" data-appraisal-id="' . $row['id'] . '"><i class="far fa-plus"></i> New Update</button>
																				';


																echo '<input type="hidden" id="pg_upd_count_' . $obj['id'] . '" name="pg_upd_count_' . $obj['id'] . '" value="' . $upd_count . '">' . "\n";
																echo "		</div>\n";
																echo '		<div class="note-actions note-actions-center">' . "\n";
																echo '			<!--a href="../appraisal_project_goal_objectives/edit.php?id=' . $obj['id'] . '&aid=' . $id . '&pid=' . $goal['id'] . '" data-fancybox data-type="iframe"><button type="button" class="btn btn-edit mr-2">Edit <i class="far fa-edit"></i></button></a-->' . "\n";
																echo '			<!--button type="button" name="delete_note_' . $obj['id'] . '" class="btn btn-default removeProjectGoalNote" data-id="' . $obj['id'] . '">Delete <i class="far fa-trash-alt"></i></button-->' . "\n";
																echo "		</div>\n";
																echo "	</div>\n";


																echo "</div>\n\n";

																$disabled = !empty( $obj['completed_date'] ) ? 'disabled' : '';
																$disabled = false;

																echo '
																<form class="project_goal_objective_form" action="edit.php?id=' . $id . '" role="form" method="POST" onSubmit="//return validateForm();" style="width: 100%;">
																<input type="hidden" name="update_objective" value="1">
																<input type="hidden" name="project_goal_id" value="' . $goal['id'] . '">
																<input type="hidden" name="objective_id" value="' . $obj['id'] . '">
																<input type="hidden" name="due_date" value="' . $obj['due_date'] . '">
																<input type="hidden" name="objective_type_id" value="' . $obj['objective_type_id'] . '">
																<input type="hidden" name="goal" value="' . $obj['goal'] . '">
																<div class="row px-3"><h3>Submit Objective</h3></div>
																<div class="row" style="width: 100%;"> <!-- objective properties -->
																	<div class="clearfix"></div>
																	<div class="form-group col-md-3">
																		<label for="completed_date" class="col-form-label">Due Date</label>
																		<div class="form-field">
																			<input type="date" class="form-control" id="due_date" placeholder="" disabled value="'. date( 'Y-m-d', strtotime( $obj['due_date'] ) ) . '">
																		</div>
																	</div>
																	<div class="form-group col-md-3">
																		<label for="completed_date" class="col-form-label">Completed Date</label>
																		<div class="form-field">
																			<input type="date" class="form-control" id="completed_date_' . $obj['id'] . '" name="completed_date" placeholder="" value="' . $obj['completed_date'] . '" ' . $disabled . ' required>
																		</div>
																	</div>
																	';

																if ( (int)$obj['objective_type_id'] == 1 ) { // date based
																	echo '
																			<div class="form-group col-md-3">
																				<label for="rating" class="col-form-label">Rating</label>
																				<div class="form-field">
																					<input type="number" class="form-control" id="rating" name="rating" placeholder="" style="max-width: 200px;" max="10" min="1" value="' . $obj['rating'] . '" ' . $disabled . '>
																				</div>
																			</div>
																		';
																} else if ( (int)$obj['objective_type_id'] == 2 ) { // Numeric based
																	//$sql = 'SELECT SUM( qty ) AS actual FROM appraisal_project_goal_objective_updates
																	//				WHERE appraisal_id = ? AND appraisal_project_goal_id = ? AND appraisal_project_goal_objective_id = ?';
																	//$sums = $conn->query( $sql, array( $row['id'], $goal['id'], $obj['id'] ) );
																	//if ( $conn->num_rows() > 0 ) {
																	//	$sum = $conn->fetch( $sums );
																	//}
																	echo '
																		<input type="hidden" name="actual_score" value="' . $obj['actual'] . '">
																		<div class="form-group col-md-3">
																			<label for="goal_score" class="col-form-label">Target</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="goal_score" placeholder="" disabled value="'. $obj['goal'] . '">
																			</div>
																		</div>
																		<div class="form-group col-md-3">
																			<label for="rating" class="col-form-label">Actual</label>
																			<div class="form-field">
																				<input type="number" class="form-control actual_score" id="actual_score_' . $obj['id'] . '" placeholder="" style="max-width: 200px;" min="1" value="' . $obj['actual'] . '" disabled>
																			</div>
																		</div>
																		';
																} else if ( (int)$obj['objective_type_id'] == 3 ) { // Score based
																	echo '
																		<div class="form-group col-md-3">
																			<label for="goal_score" class="col-form-label">Target Score</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="goal" name="goal" placeholder="" disabled value="'. $obj['goal'] . '">
																			</div>
																		</div>
																		<div class="form-group col-md-3">
																			<label for="rating" class="col-form-label">Actual Score</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="actual" name="actual" placeholder="" style="max-width: 200px;" min="1" value="' . $obj['actual'] . '" ' . $disabled . '>
																			</div>
																		</div>
																		';
																	}

																	if ( !$disabled ) {
																		echo '
																			<div class="form-group col-md-3">
																				<input type="submit" name="submit" id="submit" value="Submit" class="btn btn-primary btn-sm">
																			</div>
																		</div>
																		</form>
																		';
																	}

																echo '<input type="hidden" id="note_' . $obj['id'] . '_project_goal_id" name="note_' . $obj['id'] . '_project_goal_id" value="' . $goal['id'] . '">' . "\n";

																$obj_count++;
																echo '<hr width="100%" style="color: #999; margin: 0px auto;" />';
															}
														} else {
															echo '<div class="alert alert-primary alert_note alert_no_pg_objectives_' . $goal['id'] . '">No objectives have been created.</div>';
														}
														echo '<input type="hidden" id="pg_obj_count_' . $goal['id'] . '" name="pg_obj_count_' . $goal['id'] . '" value="' . $obj_count . '">' . "\n";
													}
													?>
												</div>
											</div>

											<?php
													echo '
												</div>
													';
												}
											} else {
												echo '<div class="alert alert-warning">No project goals found.</div>';
											}
											?>

								</div>
								<!-- ################################### // PROJECT GOAL SECTION ################################ -->

								<div class="clearfix"></div>

								<!-- ################################### INDIVIDUAL GOAL SECTION ################################ -->
								<a name="ind_goals"></a>

								<h4 class="green builder_title">Individual Goals
									<div class="total-weight">TOTAL WEIGHT &nbsp;
									<span id="individual_weight_sum" class="weight_sum"><?php echo $individual_goals_weight; ?>%</span>
									<span class="final_text">FINAL SCORE</span> &nbsp;<span id="individual_final_score" class="final_score"> 17%</span>
									<span class="total_plus">+</span></div>
								</h4>
								<div class="proj_total_toggle">
									Please see the chart below for an explanation of how your score was calculated:
									<br>
									<table border="1" cellpadding="5">
										<tr><th>Score</th><th>Percent</th></tr>
										<tr><td>4.5 to 5.0</td><td>20%</td></tr>
										<tr><td>4.0 to 4.4</td><td>18%</td></tr>
										<tr><td>3.5 to 3.9</td><td>16%</td></tr>
										<tr><td>3.0 to 3.4</td><td>14%</td></tr>
										<tr><td>2.5 to 2.9</td><td>10%</td></tr>
										<tr><td>Under 2.5</td><td>5%</td></tr>
									</table>
								</div>

								<div id="individual_goals" class="appraisal_section">
											<?php
											$sql = 'SELECT a.*, b.title, b.description FROM appraisal_individual_goals a, individual_goals b
															WHERE a.appraisal_id = ? AND a.individual_goal_id = b.id';
											$goals = $conn->query( $sql, array( $row['id'] ) );
											if ( $conn->num_rows() > 0 ) {
												while( $goal = $conn->fetch( $goals ) ) {
													$description = stripslashes( $goal['description'] );
													echo '
												<a name="ig_' . $goal['id'] . '"></a>
												<div class="appraisal_individual_goal individual_goal_' . $goal['id'] . '">
													<h3>' . $conn->parseOutputString( $goal['title'] ) . '</h3>
													<p>' . $description . '</p>
													';
											?>
											<div class="row">
												<h4 class="float-left">Objectives</h4>
												<div class="clearfix"></div>
												<div class="form-group col-md-12 objective_section" id="individual_goal_objectives_<?php echo $goal['id']; ?>">

													<?php
													$obj_count = 0;
													if ( $goal['id'] ) {
														$obj_count = 0;
														$sql = 'SELECT a.*, b.title, b.description, b.objective_type_id, c.status, d.objective_type
																		FROM appraisal_individual_goal_objectives a, individual_goal_objectives b, individual_goal_objective_statuses c, objective_types d
																		WHERE a.appraisal_id = ? AND a.appraisal_individual_goal_id = ? AND a.objective_id = b.id AND a.status_id = c.id AND b.objective_type_id = d.id';
														$objs = $conn->query( $sql, array(  $id, $goal['id'] ) );
														if ( $conn->num_rows() > 0 ) {
															// display the notes
															while( $obj = $conn->fetch( $objs ) ) {
																$start_date = !empty( $obj['start_date'] ) ? date( 'm/d/Y', strtotime( $obj['start_date'] ) ) : '';
																$due_date = !empty( $obj['due_date'] ) ? date( 'm/d/Y', strtotime( $obj['due_date'] ) ) : '';
																$completed_date = !empty( $obj['completed_date'] ) ? date( 'm/d/Y', strtotime( $obj['completed_date'] ) ) : '';
																echo '<a id="ig_obj_' . $obj['id'] . '"></a>';
																echo '<div id="individual_goal_objective_' . $obj['id'] . '" class="note form-group">' . "\n";
																echo '	<!--div class="note-title">' . "\n";
																echo '		<div class="obj_date note-date">' . date( 'm/d/Y h:i a', strtotime( $obj['date_created'] ) ) . '</div>' . "\n";
																echo "	</div-->\n";
																echo '	<div class="note-content">' . "\n";
																echo '		<div class="note-description px-2">' . "\n";

																if ( isset( $objigmsg[(int)$obj['id']] ) ) {
																	echo '<div class="alert alert-success alert-obj-upd">' . $objigmsg[(int)$obj['id']] . '</div>';
																}
																if ( isset( $objigerr[(int)$obj['id']] ) ) {
																	echo '<div class="alert alert-danger alert-obj-upd">' . $objigerr[(int)$obj['id']] . '</div>';
																}

																echo '			<div class="mgr_approval">
																							<div><label for="chkIGMgrApproved_' . $obj['id'] . '">Manager<br> Approved </label><input type="checkbox" id="chkIGMgrApproved_' . $obj['id'] . '" class="chkIGMgrApproved"  data-objective-id="' . $obj['id'] . '" ' . ( (int)$obj['mgr_approved'] ? 'CHECKED DISABLED' : '' ) . '></div>
																						</div>
																';
																echo '			<strong class="objective_title">' . stripslashes( $obj['title'] ) . "</strong><br>\n";
																echo '			' . stripslashes( $obj['description'] ) . "<br>\n
																						<div class=\"row my-3\">
																							<div class=\"obj_label\"><strong>Status:</strong> " . $obj['status'] . "</div>
																							<div class=\"obj_label\"><strong>Start:</strong> " . $start_date . "</div>
																							<div class=\"obj_label\"><strong>Due:</strong> " . $due_date . "</div>
																							<div class=\"obj_label\"><strong>Completed:</strong> " . $completed_date . "</div>
																							<div class=\"obj_label\"><strong>Type:</strong> " . $obj['objective_type'] . "</div>
																						</div>
																							";

																///////////////////////
																// UPDATES
																///////////////////////


																echo "
																						</div>
																";


																echo '<div class="update_section">
																				<h4>Updates</h4>
																				<div id="ig_updates_' . $obj['id'] . '" class="updates">
																				';
																$sql = 'SELECT a.*, b.first_name, b.last_name, c.first_name AS employee_fname, c.last_name AS employee_lname
																				FROM appraisal_individual_goal_objective_updates a, Admins b, employees c
																				WHERE a.appraisal_individual_goal_objective_id = ? AND a.admin_id = b.id AND a.employee_id = c.id
																				ORDER BY a.month_no';
																$upds = $conn->query( $sql, array( $obj['id'] ) );
																$upd_count = 0;
																if ( $conn->num_rows() > 0 ) {
																	while ( $upd = $conn->fetch( $upds ) ) {
																		echo '	<div id="ig_upd_' . $upd['id'] . '" class="note-content note-content-update">' . "\n";
																		echo '		<div class="note-description px-2">' . "\n";
																		echo '
																					<div class="row">
																					';

																		if ( (int)$obj['objective_type_id'] == 1 ) { // Date based
																			if ( (int)$upd['status'] == 0 )
																				echo '
																					<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																					';
																		} else if ( (int)$obj['objective_type_id'] == 2 ) { // Number based
																			$month_lbl = $month_lbls[(int)$upd['month_no']];
																			echo '
																				<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																				<div class="obj_label_mo"><strong>Month:</strong> ' . $month_lbl . '</div>
																				<div class="obj_label_qty"><strong>Qty:</strong> ' . $upd['qty'] . '</div>
																				';
																		} else {
																			echo '
																				<div class="obj_label"><strong>Note:</strong> ' . stripslashes( $upd['note'] ) . '</div>
																				<div class="obj_label_date"><strong>Date:</strong> ' . date( 'm/d/Y', strtotime( $upd['date_created'] ) ) . '</div>
																				';
																		}

																		if ( (int)$upd['admin_id'] > 1 )
																			echo '<div class="obj_label"><strong>Entered by:</strong> ' . $upd['first_name'] . ' ' . $upd['last_name'] . '</div>';
																		else
																			echo '<div class="obj_label"><strong>Entered by:</strong> ' . $upd['employee_fname'] . ' ' . $upd['employee_lname'] . '</div>';

																			echo '
																			<div class="upd_buttons">
																			';

																			if ( $upd['attachment'] )
																				echo '<a href="/assets/FuTaiElaIQ/appraisal_individual_goal_updates/' . $upd['attachment'] . '" title="Download Attachment" download><img src="/manager/images/ico_paper_clip.png" height="26" width="17"></a>';
																			else
																				echo '<a href="#"><img src="/manager/images/blank.png" height="26" width="17"></a>';

																			echo '
																				<a href="edit_individual_goal_objective.php?aid=' . $id . '&gid=' . $goal['id'] . '&oid=' . $obj['id'] . '&id=' . $upd['id'] . '" data-fancybox data-type="iframe" class="btn btn-default btn-small btn-edit">Edit<i class="fal fa-edit"></i></a>
																				<button class="btn btn-small btn-remove removeIGUpdate" data-id="' . $upd['id'] . '" data-individual-goal-id="' . $goal['id'] . '" data-objective-id="' . $obj['id'] . '">Del<i class="fas fa-trash"></i></button>
																			</div>
																			';


																		echo '<!--/div-->
																					</div><!--// row -->
																		';
																		$upd_count++;
																		echo '	</div>' . "\n";
																		echo '</div>' . "\n";
																	}
																} else {
																	echo "\n<div id=\"no_updates_" . $obj['id'] . "\" class=\"no_updates\">No updates have been posted</div>\n";
																}

																echo '
																				</div> <!-- // updates -->
																				<button id="new_ig_obj_update_' . $obj['id'] . '" class="btn btn-primary new_ig_objective_update btn-sm" data-id="' . $obj['id'] . '" data-type-id="' . $obj['objective_type_id'] . '" data-objective-id="' . $obj['objective_id'] . '" data-individual-goal-id="' . $goal['id'] . '" data-individual-type-id="' . $obj['objective_type_id'] .
																				'" data-appraisal-id="' . $row['id'] . '"><i class="far fa-plus"></i> New Update</button>
																				';


																echo '<input type="hidden" id="ig_upd_count_' . $obj['id'] . '" name="ig_upd_count_' . $obj['id'] . '" value="' . $upd_count . '">' . "\n";
																echo "		</div>\n";
																echo '		<div class="note-actions note-actions-center">' . "\n";
																echo '			<!--a href="../appraisal_individual_goal_objectives/edit.php?id=' . $obj['id'] . '&aid=' . $id . '&pid=' . $goal['id'] . '" data-fancybox data-type="iframe"><button type="button" class="btn btn-edit mr-2">Edit <i class="far fa-edit"></i></button></a-->' . "\n";
																echo '			<!--button type="button" name="delete_note_' . $obj['id'] . '" class="btn btn-default removeProjectGoalNote" data-id="' . $obj['id'] . '">Delete <i class="far fa-trash-alt"></i></button-->' . "\n";
																echo "		</div>\n";
																echo "	</div>\n";


																echo "</div>\n\n";

																$disabled = !empty( $obj['completed_date'] ) ? 'disabled' : '';
																$disabled = false;

																echo '
																<form class="individual_goal_objective_form" action="edit.php?id=' . $id . '" role="form" method="POST" onSubmit="//return validateForm();" style="width: 100%;">
																<input type="hidden" name="update_ig_objective" value="1">
																<input type="hidden" name="individual_goal_id" value="' . $goal['id'] . '">
																<input type="hidden" name="objective_id" value="' . $obj['id'] . '">
																<input type="hidden" name="due_date" value="' . $obj['due_date'] . '">
																<input type="hidden" name="objective_type_id" value="' . $obj['objective_type_id'] . '">
																<input type="hidden" name="goal" value="' . $obj['goal'] . '">
																<div class="row px-3"><h3>Submit Objective</h3></div>
																<div class="row" style="width: 100%;"> <!-- objective properties -->
																	<div class="form-group col-md-3">
																		<label for="completed_date" class="col-form-label">Due Date</label>
																		<div class="form-field">
																			<input type="date" class="form-control" id="due_date" placeholder="" disabled value="'. date( 'Y-m-d', strtotime( $obj['due_date'] ) ) . '">
																		</div>
																	</div>
																	<div class="form-group col-md-3">
																		<label for="completed_date" class="col-form-label">Completed Date</label>
																		<div class="form-field">
																			<input type="date" class="form-control" id="completed_date_ig_' . $obj['id'] . '" name="completed_date" placeholder="" value="' . $obj['completed_date'] . '" ' . $disabled . ' required>
																		</div>
																	</div>
																	';

																if ( (int)$obj['objective_type_id'] == 1 ) { // date based
																	echo '
																			<div class="form-group col-md-3">
																				<label for="rating" class="col-form-label">Rating</label>
																				<div class="form-field">
																					<input type="number" class="form-control" id="rating" name="rating" placeholder="" style="max-width: 200px;" max="10" min="1" value="' . $obj['rating'] . '" ' . $disabled . '>
																				</div>
																			</div>
																		';
																} else if ( (int)$obj['objective_type_id'] == 2 ) { // Numeric based
																	//$sql = 'SELECT SUM( qty ) AS actual FROM appraisal_project_goal_objective_updates
																	//				WHERE appraisal_id = ? AND appraisal_project_goal_id = ? AND appraisal_project_goal_objective_id = ?';
																	//$sums = $conn->query( $sql, array( $row['id'], $goal['id'], $obj['id'] ) );
																	//if ( $conn->num_rows() > 0 ) {
																	//	$sum = $conn->fetch( $sums );
																	//}
																	echo '
																		<input type="hidden" name="actual_score" value="' . $obj['actual'] . '">
																		<div class="form-group col-md-3">
																			<label for="goal_score" class="col-form-label">Target</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="goal_score" placeholder="" disabled value="'. $obj['goal'] . '">
																			</div>
																		</div>
																		<div class="form-group col-md-3">
																			<label for="rating" class="col-form-label">Actual</label>
																			<div class="form-field">
																				<input type="number" class="form-control actual_score" id="actual_score_' . $obj['id'] . '" placeholder="" style="max-width: 200px;" min="1" value="' . $obj['actual'] . '" disabled>
																			</div>
																		</div>
																		';
																} else if ( (int)$obj['objective_type_id'] == 3 ) { // Score based
																	echo '
																		<div class="form-group col-md-3">
																			<label for="goal_score" class="col-form-label">Target Score</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="goal" name="goal" placeholder="" disabled value="'. $obj['goal'] . '">
																			</div>
																		</div>
																		<div class="form-group col-md-3">
																			<label for="rating" class="col-form-label">Actual Score</label>
																			<div class="form-field">
																				<input type="number" class="form-control" id="actual" name="actual" placeholder="" style="max-width: 200px;" min="1" value="' . $obj['actual'] . '" ' . $disabled . '>
																			</div>
																		</div>
																		';
																	}

																	if ( !$disabled ) {
																		echo '
																			<div class="form-group col-md-3">
																				<input type="submit" name="submit" id="submit" value="Submit" class="btn btn-primary btn-sm">
																			</div>
																		</div>
																		</form>
																		';
																	}

																echo '<input type="hidden" id="note_' . $obj['id'] . '_individual_goal_id" name="note_' . $obj['id'] . '_individual_goal_id" value="' . $goal['id'] . '">' . "\n";

																$obj_count++;
																echo '<hr width="100%" style="color: #999; margin: 0px auto;" />';
															}
														} else {
															echo '<div class="alert alert-primary alert_note alert_no_ig_objectives_' . $goal['id'] . '">No objectives have been created.</div>';
														}
														echo '<input type="hidden" id="ig_obj_count_' . $goal['id'] . '" name="ig_obj_count_' . $goal['id'] . '" value="' . $obj_count . '">' . "\n";
													}
													?>
												</div>
											</div>

											<?php
													echo '
												</div>
													';
												}
											} else {
												echo '<div class="alert alert-warning">No individual goals found.</div>';
											}
											?>

								</div>


								<!-- ################################### // INDIVIDUAL GOAL SECTION ################################ -->
								<?php } else { ?>
									<div class="alert alert-info"><?php echo $msg; ?></div>
								<?php } ?>
							</div>

						</div>
						<!--/row-->

						<footer class="container-fluid">
								<p class="text-right small">©2019 All rights reserved.</p>
						</footer>

					</div>
					<!--/main col-->

				</div>

			</div>

			<div id="sticky-sidebar">

				<?php
				//$sql = 'SELECT competency_weight, project_goal_weight, individual_goal_weight FROM periods WHERE id = ?';
				//$periods = $conn->query( $sql, array( $_SESSION['admin_period_id'] ) );
				//if ( $conn->num_rows() > 0 ) {
				//	$period = $conn->fetch( $periods );
				//}
				$sql = 'SELECT a.*, b.title, b.desc_mgr, b.desc_emp
								FROM appraisal_competencies a, competencies b, appraisals c
								WHERE a.appraisal_id = ? AND a.competency_id = b.id AND a.appraisal_id = c.id AND c.company_id = ?';
				$comps = $conn->query( $sql, array( $row['id'], $_SESSION['admin_company_id'] ) );

				if ( $conn->num_rows() > 0 ) {
					echo '<ul>';
					echo '<li class="sidebar_title orange_bg"><a href="#comps">Competencies</a> (' . $competencies_weight . '%)</li>' . "\n";
					while( $comp = $conn->fetch( $comps ) ) {
						echo '
						<li class="item-toc ">
							<a href="#co_' . $comp['id'] . '" class="sidebar-link "><span>' . $comp['title'] . '</span></a>
						</li>
						';
					}
					echo '</ul>';
				}

				$sql = 'SELECT a.*, b.title
								FROM appraisal_project_goals a, project_goals b
								WHERE a.appraisal_id = ? AND a.project_goal_id = b.id AND b.company_id = ?';
				$goals = $conn->query( $sql, array( $row['id'], $_SESSION['admin_company_id'] ) );
				if ( $conn->num_rows() > 0 ) {
					echo '<ul>';
					echo '<li class="sidebar_title blue_bg"><a href="#pro_goals">Project Goals</a> (' . $project_goals_weight . '%)</li>' . "\n";
					while( $goal = $conn->fetch( $goals ) ) {
						echo '
						<li class="item-toc ">
							<a href="#pg_' . $goal['id'] . '" class="sidebar-link "><span>' . $goal['title'] . '</span></a>
						</li>
						';
					}
					echo '</ul>';
				}

				$sql = 'SELECT a.*, b.title
								FROM appraisal_individual_goals a, individual_goals b
								WHERE a.appraisal_id = ? AND a.individual_goal_id = b.id AND b.company_id = ?';
				$goals = $conn->query( $sql, array( $row['id'], $_SESSION['admin_company_id'] ) );
				if ( $conn->num_rows() > 0 ) {
					echo '<ul>';
					echo '<li class="sidebar_title green_bg"><a href="#ind_goals">Individual Goals</a> (' . $individual_goals_weight . '%)</li>' . "\n";
					while( $goal = $conn->fetch( $goals ) ) {
						echo '
						<li class="item-toc ">
							<a href="#ig_' . $goal['id'] . '" class="sidebar-link "><span>' . $goal['title'] . '</span></a>
						</li>
						';
					}
					echo '</ul>';
				}
				?>

			</div>
<!--/.container-->
<script>
	var menuitem = "Appraisals";
</script>
<!-- Core Scripts - Include with every page -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="../includes/tinymce/tinymce.min.js"></script>
<script src="/manager/js/jquery.fancybox.min.js"></script>
<script src="/manager/js/imagine.js"></script>
<script src="/manager/js/appraisal_builder.js"></script>
<script>
var upd_token = '<?php echo $_SESSION['upd_token']; ?>';
var appraisal_id = '<?php echo $id; ?>';

$(document).ready(function(){
	<?php if ( $jump_anchor_id ) { ?>
		$(document).scrollTop( $("#<?php echo $jump_anchor_id; ?>").offset().top - 25 );
	<?php } ?>

	$(document).on('focusin', '.input-competency-weight input', function() {
			$(this).data('val', $(this).val());
	}).on('change','.input-competency-weight input', function(){
			var prev = $(this).data('val');
			var current = $(this).val();
			var employee_id = $(this).attr('data-employee-id');
			//var appraisal_id = $(this).attr('data-appraisal-id');
			var competency_id = $(this).attr('data-competency-id');
			var total = getCompetencyWeightSum( employee_id );

			if ( total > 100 ) {
				$('#weight_sum').addClass('total_error');
				$(this).addClass('total_error_input');
				$('#weight_sum').html(total + '%');
				obj_dirty = true;
			} else {
				$(this).removeClass('total_error_input');
				$('#weight_sum').removeClass('total_error');
				$('#weight_sum').html(total + '%');
				obj_dirty = false;
				console.log('saving weight:' + appraisal_id + ',' + competency_id + ',' + employee_id);
				$.ajax( {
					url : 'save_competency_weight.php',
					type: "POST",
					data : { appraisal_id: appraisal_id,competency_id: competency_id, employee_id: employee_id, weight: $(this).val(), upd_token: upd_token },
					success:function( data, textStatus, jqXHR ) {
						console.log( data );
					},
					error: function( jqXHR, textStatus, errorThrown ) {
						//if fails
						console.log('error:' + errorThrown);
					}
				});
			}
	});
});

$('#project_goals').on('click', '.removeUpdate', function() {
	var project_goal_id = $(this).attr('data-project-goal-id');
	var objective_id = $(this).attr('data-objective-id');
	var update_id = $(this).attr('data-id');
	console.log('deleting:' + project_goal_id + ',' + objective_id + ',' + update_id );
	$.ajax( {
		url : 'del_project_goal_objective_update.php',
		type: "POST",
		data : { appraisal_id: <?php echo $id; ?>, project_goal_id: project_goal_id, objective_id: objective_id, update_id: update_id, upd_token: '<?php echo $_SESSION['upd_token']; ?>' },
		success:function( data, textStatus, jqXHR ) {
			console.log(data);
			$('#upd_' + update_id ).fadeOut( 'slow', function() {
				$('#upd_' + update_id ).remove();
			});

			getObjectiveActual( <?php echo $id; ?>, objective_id )
			console.log(data);
		},
		error: function( jqXHR, textStatus, errorThrown ) {
			//if fails
			console.log('error:' + errorThrown);
		}
	});
	return false;
});

$('#individual_goals').on('click', '.removeIGUpdate', function() {
	var individual_goal_id = $(this).attr('data-individual-goal-id');
	var objective_id = $(this).attr('data-objective-id');
	var update_id = $(this).attr('data-id');
	console.log('deleting:' + individual_goal_id + ',' + objective_id + ',' + update_id );
	$.ajax( {
		url : 'del_individual_goal_objective_update.php',
		type: "POST",
		data : { appraisal_id: <?php echo $id; ?>, individual_goal_id: individual_goal_id, objective_id: objective_id, update_id: update_id, upd_token: '<?php echo $_SESSION['upd_token']; ?>' },
		success:function( data, textStatus, jqXHR ) {
			console.log(data);
			$('#ig_upd_' + update_id ).fadeOut( 'slow', function() {
				$('#ig_upd_' + update_id ).remove();
			});

			getIGObjectiveActual( <?php echo $id; ?>, objective_id )
			console.log(data);
		},
		error: function( jqXHR, textStatus, errorThrown ) {
			//if fails
			console.log('error:' + errorThrown);
		}
	});
	return false;
});

//function getCompetencyWeightSum() {
//	var sum = 0;
//	$('.competency-weight').each(function(i, obj) {
//		sum = sum + parseInt( $(obj).val() );
//	});
//	console.log('w:'+sum);
//	$('#weight_sum').html(sum + '%');
//	return sum;
//}
//getCompetencyWeightSum();

$(document).ready(function() {
	$('[data-fancybox]').fancybox({
		toolbar  : false,
		smallBtn : true,
		modal: true,
		iframe : {
			preload : false,
			css : {
					width : '800px',
					height: '700px',
					padding: '0px'
			},
			buttons: [
		    "close"
		  ],
		},
		afterClose: function( instance, current ) {
			window.location.href = window.location.href;
		}
	});

	window.setTimeout(function() {
		$(".alert-obj-upd").fadeTo(500, 0).slideUp(500, function(){
			$(this).remove();
		});
	}, 2000);

});

</script>

</body>

</html>
<?php $conn->close(); ?>